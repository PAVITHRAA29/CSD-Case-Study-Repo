package com.example.Demo.Service;

import com.example.Demo.Model.User;
import com.example.Demo.Repo.UserRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class UserService {

    @Autowired
    private UserRepo userRepo;

    public List<User> getAllUsers() {
        return userRepo.findAll(Sort.by("id").ascending());
    }

    public User getUserById(int id) {
        Optional<User> optional = userRepo.findById(id);
        User user = null;

        if (optional.isPresent()){
            user = optional.get();
        }else {
            throw new RuntimeException("User not found for id : " + id);
        }

        return user;
    }

    public void saveUser(User user) {
        this.userRepo.save(user);
    }

    public void deleteUserById(int id) {
        this.userRepo.deleteById(id);
    }

    public void updateUserById(User user) {
        this.userRepo.save(user);
    }

}
