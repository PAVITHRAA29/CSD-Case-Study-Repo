package com.example.Demo.Controller;

import com.example.Demo.Service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.User;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

@Controller
public class UserController {

    @Autowired
    private UserService userService;

    @PostMapping("/register")
    public String register(User user){
        return userService.saveUser(user);
    }

    @PostMapping("/Update/{id}")
    public String Update(@PathVariable ( value = "id") int id, User user) {
        User user1 = userService.getUserById(id);
        return userService.saveUser(user1);
    }

    @DeleteMapping("/delete/{id}")
    public String  delete(@PathVariable(value = "id") int id) {
        return userService.deleteUserById(id);
    }

    @GetMapping("/allUser")
    public String getAllEmployee() {
        return userService.getAllUsers();
    }

}
