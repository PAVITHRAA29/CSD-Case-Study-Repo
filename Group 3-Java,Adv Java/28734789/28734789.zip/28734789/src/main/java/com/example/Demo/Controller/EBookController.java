package com.example.Demo.Controller;

import com.example.Demo.Service.EbookService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.EBookdetails.EBook;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

@Controller
public class EBookController {

    @Autowired
    private EbookService ebookService;

    @PostMapping("/register")
    public String register(EBook eBook){
        return ebookService.saveEBook(eBook);
    }

    @PostMapping("/Update/{id}")
    public String showFormForUpdate(@PathVariable( value = "id") int id, EBook eBook) {
        EBook EBook1 = ebookService.getEBookById(id);
        return ebookService.saveEBook(EBook1);
    }

    @DeleteMapping("/delete/{id}")
    public String  delete(@PathVariable(value = "id") int id) {
        return ebookService.deleteEBookById(id);
    }

    @GetMapping("/allEBook")
    public String  getAll() {
        return ebookService.getAllEBooks();
    }
}
