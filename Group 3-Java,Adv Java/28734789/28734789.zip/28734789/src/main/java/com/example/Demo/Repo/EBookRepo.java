package com.example.Demo.Repo;

import com.example.Demo.Model.EBook;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface EBookRepo extends JpaRepository<EBook, Integer> {



}
