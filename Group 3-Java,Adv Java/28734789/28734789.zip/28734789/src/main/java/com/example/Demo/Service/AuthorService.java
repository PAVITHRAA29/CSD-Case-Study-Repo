package com.example.Demo.Service;

import com.example.Demo.Model.Author;
import com.example.Demo.Model.Author;
import com.example.Demo.Repo.AuthorRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class AuthorService {

    @Autowired
    private AuthorRepo authorRepo;

    public List<Author> getAllAuthor() {
        return authorRepo.findAll(Sort.by("id").ascending());
    }

    public Author getAuthorById(int id) {
        Optional<Author> optional = authorRepo.findById(id);
        Author Author = null;

        if (optional.isPresent()){
            Author = optional.get();
        }else {
            throw new RuntimeException("Author not found for id : " + id);
        }

        return Author;
    }

    public void saveAuthor(Author author) {
        this.authorRepo.save(author);
    }

    public void deleteAuthorById(int id) {
        this.authorRepo.deleteById(id);
    }

    public void updateAuthorById(Author author) {
        this.authorRepo.save(author);
    }
}
