package com.example.Demo.Controller;

import com.example.Demo.Model.Author;
import com.example.Demo.Service.AuthorService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

@Controller
public class AuthorController {

    @Autowired
    private AuthorService authorService;

    @PostMapping("/register")
    public String register(Author author){
        return authorService.saveAuthor(author);
    }

    @PostMapping("/Update/{id}")
    public String Update(@PathVariable( value = "id") int id, Author author) {
        Author Author1 = AuthorService.getAuthorById(id);
        return authorService.saveAuthor(Author1);
    }

    @DeleteMapping("/delete/{id}")
    public String  delete(@PathVariable(value = "id") int id) {
        return authorService.deleteAuthorById(id);
    }

    @GetMapping("/allAuthor")
    public String  getAll() {
        return authorService.getAllAuthor();
    }
}
