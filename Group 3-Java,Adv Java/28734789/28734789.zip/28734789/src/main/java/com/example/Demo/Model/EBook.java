package com.example.Demo.Model;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;

@Entity
@Data
@Table
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class EBook {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int ebook_id;

    private String title;

    private String genre;

    private Date publication_date;

    @OneToOne
    private int author_id;

    private int available_copies;

}
