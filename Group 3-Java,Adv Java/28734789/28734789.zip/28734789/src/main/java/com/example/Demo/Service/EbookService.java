package com.example.Demo.Service;

import com.example.Demo.Model.EBook;
import com.example.Demo.Model.User;
import com.example.Demo.Repo.EBookRepo;
import com.example.Demo.Repo.UserRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class EbookService {

    @Autowired
    private EBookRepo eBookRepo;

    public List<EBook> getAllBooks() {
        return eBookRepo.findAll(Sort.by("id").ascending());
    }

    public EBook getBookById(int id) {
        Optional<EBook> optional = eBookRepo.findById(id);
        EBook eBook = null;

        if (optional.isPresent()){
            eBook = optional.get();
        }else {
            throw new RuntimeException("Book not found for id : " + id);
        }

        return eBook;
    }

    public void saveBook(EBook eBook) {
        this.eBookRepo.save(eBook);
    }

    public void deleteBookById(int id) {
        this.eBookRepo.deleteById(id);
    }

    public void updateBookById(EBook eBook) {
        this.eBookRepo.save(eBook);
    }
}
