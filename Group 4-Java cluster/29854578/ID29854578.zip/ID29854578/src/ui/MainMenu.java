package ui;

import service.SampleService;
import service.ExperimentService;
import service.ResearcherService;

import java.util.Scanner;

public class MainMenu {
    public static void main(String[] args) {
        ExperimentService experimentService = new ExperimentService();
        SampleService sampleService = new SampleService();
        ResearcherService researcherService = new ResearcherService();
        
        try (Scanner scanner = new Scanner(System.in)) {
            while (true) {
                System.out.println("=== Life Sciences Research Lab Management ===");
                System.out.println("1. Manage Experiments");
                System.out.println("2. Manage Samples");
                System.out.println("3. Manage Researchers");
                System.out.println("4. Exit");
                System.out.print("Choose an option: ");
                
                int choice = scanner.nextInt();
                switch (choice) {
                    case 1:
                        System.out.println("Managing experiments...");
                        experimentService.manageExperiments();
                        break;
                    case 2:
                        System.out.println("Managing samples...");
                        sampleService.manageSamples();
                        break;
                    case 3:
                        System.out.println("Managing researchers...");
                        researcherService.manageResearchers();
                        break;
                    case 4:
                        System.out.println("Exiting...");
                        return;
                    default:
                        System.out.println("Invalid option. Please try again.");
                }
            }
        }
    }
}
