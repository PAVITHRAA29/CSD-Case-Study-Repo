package service;

import dao.ExperimentDAO;
import model.Experiment;

import java.util.List;
import java.util.Scanner;

/**
 * Service class for managing experiments.
 */

public class ExperimentService {
    private ExperimentDAO experimentDAO = new ExperimentDAO();

/**
 * Service class for managing experiments.
 */

    public void manageExperiments() {
        Scanner scanner = new Scanner(System.in);
        while (true) {
            System.out.println("=== Experiment Management ===");
            System.out.println("1. Add Experiment");
            System.out.println("2. View Experiment");
            System.out.println("3. Update Experiment");
            System.out.println("4. Delete Experiment");
            System.out.println("5. List All Experiments");
            System.out.println("6. Back to Main Menu");
            System.out.print("Choose an option: ");
            int choice = scanner.nextInt();
            scanner.nextLine(); // Consume the newline character
            switch (choice) {
                case 1:
                    addExperiment();
                    break;
                case 2:
                    viewExperiment();
                    break;
                case 3:
                    updateExperiment();
                    break;
                case 4:
                    deleteExperiment();
                    break;
                case 5:
                    listAllExperiments();
                    break;
                case 6:
                    return;
                default:
                    System.out.println("Invalid option. Please try again.");
            }
        }
    }

    /**
     * Adds a new experiment by prompting the user for input.
     */

    private void addExperiment() {
        Scanner scanner = new Scanner(System.in);
        Experiment experiment = new Experiment();
        System.out.print("Enter experiment name: ");
        experiment.setName(scanner.nextLine());
        System.out.print("Enter experiment description: ");
        experiment.setDescription(scanner.nextLine());
        System.out.print("Enter start date (YYYY-MM-DD): ");
        experiment.setStartDate(scanner.nextLine());
        System.out.print("Enter end date (YYYY-MM-DD): ");
        experiment.setEndDate(scanner.nextLine());
        experimentDAO.addExperiment(experiment);
        System.out.println("Experiment added successfully.");
    }

    /**
     * Adds a new experiment by prompting the user for input.
     */
    private void viewExperiment() {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter experiment ID: ");
        int experimentId = scanner.nextInt();
        scanner.nextLine(); // Consume the newline character
        Experiment experiment = experimentDAO.getExperiment(experimentId);
        if (experiment != null) {
            System.out.println("Experiment ID: " + experiment.getExperimentId());
            System.out.println("Name: " + experiment.getName());
            System.out.println("Description: " + experiment.getDescription());
            System.out.println("Start Date: " + experiment.getStartDate());
            System.out.println("End Date: " + experiment.getEndDate());
        } else {
            System.out.println("Experiment not found.");
        }
    }

    /**
     * Updates an experiment by prompting the user for the experiment ID and new details.
     */

    private void updateExperiment() {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter experiment ID: ");
        int experimentId = scanner.nextInt();
        scanner.nextLine(); // Consume the newline character
        Experiment experiment = experimentDAO.getExperiment(experimentId);
        if (experiment != null) {
            System.out.print("Enter new experiment name (leave blank to keep current): ");
            String name = scanner.nextLine();
            if (!name.isEmpty()) {
                experiment.setName(name);
            }
            System.out.print("Enter new experiment description (leave blank to keep current): ");
            String description = scanner.nextLine();
            if (!description.isEmpty()) {
                experiment.setDescription(description);
            }
            System.out.print("Enter new start date (YYYY-MM-DD) (leave blank to keep current): ");
            String startDate = scanner.nextLine();
            if (!startDate.isEmpty()) {
                experiment.setStartDate(startDate);
            }
            System.out.print("Enter new end date (YYYY-MM-DD) (leave blank to keep current): ");
            String endDate = scanner.nextLine();
            if (!endDate.isEmpty()) {
                experiment.setEndDate(endDate);
            }
            experimentDAO.updateExperiment(experiment);
            System.out.println("Experiment updated successfully.");
        } else {
            System.out.println("Experiment not found.");
        }
    }
    /**
     * Deletes an experiment by prompting the user for the experiment ID.
     */
    private void deleteExperiment() {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter experiment ID: ");
        int experimentId = scanner.nextInt();
        scanner.nextLine(); // Consume the newline character
        experimentDAO.deleteExperiment(experimentId);
        System.out.println("Experiment deleted successfully.");
    }
    /**
     * Lists all experiments by retrieving them from the database.
     */

    private void listAllExperiments() {
        List<Experiment> experiments = experimentDAO.getAllExperiments();
        for (Experiment experiment : experiments) {
            System.out.println("Experiment ID: " + experiment.getExperimentId());
            System.out.println("Name: " + experiment.getName());
            System.out.println("Description: " + experiment.getDescription());
            System.out.println("Start Date: " + experiment.getStartDate());
            System.out.println("End Date: " + experiment.getEndDate());
            System.out.println();
        }
    }
}
