package service;

import dao.ResearcherDAO;
import model.Researcher;

import java.util.List;
import java.util.Scanner;

public class ResearcherService {
    private ResearcherDAO researcherDAO = new ResearcherDAO();
    private Scanner scanner = new Scanner(System.in); // Single instance

    public void manageResearchers() {
        while (true) {
            System.out.println("=== Researcher Management ===");
            System.out.println("1. Add Researcher");
            System.out.println("2. View Researcher");
            System.out.println("3. Update Researcher");
            System.out.println("4. Delete Researcher");
            System.out.println("5. List All Researchers");
            System.out.println("6. Back to Main Menu");
            System.out.print("Choose an option: ");
            int choice = scanner.nextInt();
            switch (choice) {
                case 1:
                    addResearcher();
                    break;
                case 2:
                    viewResearcher();
                    break;
                case 3:
                    updateResearcher();
                    break;
                case 4:
                    deleteResearcher();
                    break;
                case 5:
                    listAllResearchers();
                    break;
                case 6:
                    scanner.close(); // Close the scanner before exiting
                    return;
                default:
                    System.out.println("Invalid option. Please try again.");
            }
        }
    }

    private void addResearcher() {
        Researcher researcher = new Researcher();
        System.out.print("Enter researcher name: ");
        researcher.setName(scanner.next());
        System.out.print("Enter researcher email: ");
        researcher.setEmail(scanner.next());
        System.out.print("Enter researcher phone number: ");
        researcher.setPhoneNumber(scanner.next());
        System.out.print("Enter researcher specialization: ");
        researcher.setSpecialization(scanner.next());
        researcherDAO.addResearcher(researcher);
        System.out.println("Researcher added successfully.");
    }

    private void viewResearcher() {
        System.out.print("Enter researcher ID: ");
        int researcherId = scanner.nextInt();
        Researcher researcher = researcherDAO.getResearcher(researcherId);
        if (researcher != null) {
            System.out.println("Researcher ID: " + researcher.getResearcherId());
            System.out.println("Name: " + researcher.getName());
            System.out.println("Email: " + researcher.getEmail());
            System.out.println("Phone Number: " + researcher.getPhoneNumber());
            System.out.println("Specialization: " + researcher.getSpecialization());
        } else {
            System.out.println("Researcher not found.");
        }
    }

    private void updateResearcher() {
        System.out.print("Enter researcher ID: ");
        int researcherId = scanner.nextInt();
        Researcher researcher = researcherDAO.getResearcher(researcherId);
        if (researcher != null) {
            System.out.print("Enter new researcher name (leave blank to keep current): ");
            String name = scanner.next();
            if (!name.isEmpty()) {
                researcher.setName(name);
            }
            System.out.print("Enter new researcher email (leave blank to keep current): ");
            String email = scanner.next();
            if (!email.isEmpty()) {
                researcher.setEmail(email);
            }
            System.out.print("Enter new researcher phone number (leave blank to keep current): ");
            String phoneNumber = scanner.next();
            if (!phoneNumber.isEmpty()) {
                researcher.setPhoneNumber(phoneNumber);
            }
            System.out.print("Enter new researcher specialization (leave blank to keep current): ");
            String specialization = scanner.next();
            if (!specialization.isEmpty()) {
                researcher.setSpecialization(specialization);
            }
            researcherDAO.updateResearcher(researcher);
            System.out.println("Researcher updated successfully.");
        } else {
            System.out.println("Researcher not found.");
        }
    }

    private void deleteResearcher() {
        System.out.print("Enter researcher ID: ");
        int researcherId = scanner.nextInt();
        researcherDAO.deleteResearcher(researcherId);
        System.out.println("Researcher deleted successfully.");
    }

    private void listAllResearchers() {
        List<Researcher> researchers = researcherDAO.getAllResearchers();
        for (Researcher researcher : researchers) {
            System.out.println("Researcher ID: " + researcher.getResearcherId());
            System.out.println("Name: " + researcher.getName());
            System.out.println("Email: " + researcher.getEmail());
            System.out.println("Phone Number: " + researcher.getPhoneNumber());
            System.out.println("Specialization: " + researcher.getSpecialization());
            System.out.println();
        }
    }
}
