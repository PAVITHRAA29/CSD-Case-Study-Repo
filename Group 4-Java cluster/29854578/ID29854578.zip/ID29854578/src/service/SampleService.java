package service;

import dao.SampleDAO;
import model.Sample;

import java.util.List;
import java.util.Scanner;

public class SampleService {
    private SampleDAO sampleDAO = new SampleDAO();
    private Scanner scanner = new Scanner(System.in); // Use a single Scanner instance

    public void manageSamples() {
        while (true) {
            System.out.println("=== Sample Management ===");
            System.out.println("1. Add Sample");
            System.out.println("2. View Sample");
            System.out.println("3. Update Sample");
            System.out.println("4. Delete Sample");
            System.out.println("5. List All Samples");
            System.out.println("6. Back to Main Menu");
            System.out.print("Choose an option: ");
            int choice = scanner.nextInt();
            switch (choice) {
                case 1:
                    addSample();
                    break;
                case 2:
                    viewSample();
                    break;
                case 3:
                    updateSample();
                    break;
                case 4:
                    deleteSample();
                    break;
                case 5:
                    listAllSamples();
                    break;
                case 6:
                    return;
                default:
                    System.out.println("Invalid option. Please try again.");
            }
        }
    }

    private void addSample() {
        Sample sample = new Sample();
        System.out.print("Enter experiment ID: ");
        sample.setExperimentId(scanner.nextInt());
        scanner.nextLine(); // consume newline
        System.out.print("Enter sample name: ");
        sample.setName(scanner.nextLine());
        System.out.print("Enter sample type: ");
        sample.setType(scanner.nextLine());
        System.out.print("Enter sample quantity: ");
        sample.setQuantity(scanner.nextInt());
        sampleDAO.addSample(sample);
        System.out.println("Sample added successfully.");
    }

    private void viewSample() {
        System.out.print("Enter sample ID: ");
        int sampleId = scanner.nextInt();
        Sample sample = sampleDAO.getSample(sampleId);
        if (sample != null) {
            System.out.println("Sample ID: " + sample.getSampleId());
            System.out.println("Experiment ID: " + sample.getExperimentId());
            System.out.println("Name: " + sample.getName());
            System.out.println("Type: " + sample.getType());
            System.out.println("Quantity: " + sample.getQuantity());
        } else {
            System.out.println("Sample not found.");
        }
    }

    private void updateSample() {
        System.out.print("Enter sample ID: ");
        int sampleId = scanner.nextInt();
        scanner.nextLine(); // consume newline
        Sample sample = sampleDAO.getSample(sampleId);
        if (sample != null) {
            System.out.print("Enter new experiment ID (leave blank to keep current): ");
            String experimentId = scanner.nextLine();
            if (!experimentId.isEmpty()) {
                sample.setExperimentId(Integer.parseInt(experimentId));
            }
            System.out.print("Enter new sample name (leave blank to keep current): ");
            String name = scanner.nextLine();
            if (!name.isEmpty()) {
                sample.setName(name);
            }
            System.out.print("Enter new sample type (leave blank to keep current): ");
            String type = scanner.nextLine();
            if (!type.isEmpty()) {
                sample.setType(type);
            }
            System.out.print("Enter new sample quantity (leave blank to keep current): ");
            String quantity = scanner.nextLine();
            if (!quantity.isEmpty()) {
                sample.setQuantity(Integer.parseInt(quantity));
            }
            sampleDAO.updateSample(sample);
            System.out.println("Sample updated successfully.");
        } else {
            System.out.println("Sample not found.");
        }
    }

    private void deleteSample() {
        System.out.print("Enter sample ID: ");
        int sampleId = scanner.nextInt();
        sampleDAO.deleteSample(sampleId);
        System.out.println("Sample deleted successfully.");
    }

    private void listAllSamples() {
        List<Sample> samples = sampleDAO.getAllSamples();
        for (Sample sample : samples) {
            System.out.println("Sample ID: " + sample.getSampleId());
            System.out.println("Experiment ID: " + sample.getExperimentId());
            System.out.println("Name: " + sample.getName());
            System.out.println("Type: " + sample.getType());
            System.out.println("Quantity: " + sample.getQuantity());
            System.out.println();
        }
    }

    // Close the Scanner when you're done (you may want to do this in the main method or when exiting the program)
    public void close() {
        scanner.close();
    }
}
