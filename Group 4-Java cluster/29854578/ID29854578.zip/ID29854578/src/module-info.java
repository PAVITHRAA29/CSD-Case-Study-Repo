/**
 * 
 */
/**
 * 
 */
module ID29854578 {
	
	requires java.sql;
}