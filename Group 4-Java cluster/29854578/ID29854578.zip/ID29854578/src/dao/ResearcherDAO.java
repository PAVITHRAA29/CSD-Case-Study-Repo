package dao;

import model.Researcher;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
/**
 * Data Access Object for performing CRUD operations on Researcher entities.
 */

public class ResearcherDAO {

    /**
     * Establishes a connection to the database.
     * @return Connection object
     * @throws SQLException if a database access error occurs
     */
    private Connection getConnection() throws SQLException {
        return DriverManager.getConnection("jdbc:mysql://localhost:3306/lab_management", "root", "password"
        		+ "");
    }
    /**
     * Adds a new researcher to the database.
     * @param researcher The researcher to be added.
     */

    public void addResearcher(Researcher researcher) {
        String sql = "INSERT INTO Researcher (name, email, phone_number, specialization) VALUES (?, ?, ?, ?)";
        try (Connection conn = getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, researcher.getName());
            stmt.setString(2, researcher.getEmail());
            stmt.setString(3, researcher.getPhoneNumber());
            stmt.setString(4, researcher.getSpecialization());
            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    /**
     * Retrieves a researcher from the database by their ID.
     * @param researcherId The ID of the researcher to retrieve.
     * @return The retrieved researcher, or null if not found.
     */

    public Researcher getResearcher(int researcherId) {
        Researcher researcher = null;
        String sql = "SELECT * FROM Researcher WHERE researcher_id = ?";
        try (Connection conn = getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, researcherId);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                researcher = new Researcher();
                researcher.setResearcherId(rs.getInt("researcher_id"));
                researcher.setName(rs.getString("name"));
                researcher.setEmail(rs.getString("email"));
                researcher.setPhoneNumber(rs.getString("phone_number"));
                researcher.setSpecialization(rs.getString("specialization"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return researcher;
    }

    /**
     * Updates an existing researcher in the database.
     * @param researcher The researcher with updated information.
     */

    public void updateResearcher(Researcher researcher) {
        String sql = "UPDATE Researcher SET name = ?, email = ?, phone_number = ?, specialization = ? WHERE researcher_id = ?";
        try (Connection conn = getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, researcher.getName());
            stmt.setString(2, researcher.getEmail());
            stmt.setString(3, researcher.getPhoneNumber());
            stmt.setString(4, researcher.getSpecialization());
            stmt.setInt(5, researcher.getResearcherId());
            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    /**
     * Deletes a researcher from the database by their ID.
     * @param researcherId The ID of the researcher to delete.
     */

    public void deleteResearcher(int researcherId) {
        String sql = "DELETE FROM Researcher WHERE researcher_id = ?";
        try (Connection conn = getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, researcherId);
            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    /**
     * Retrieves all researchers from the database.
     * @return A list of all researchers.
     */
    public List<Researcher> getAllResearchers() {
        List<Researcher> researchers = new ArrayList<>();
        String sql = "SELECT * FROM Researcher";
        try (Connection conn = getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                Researcher researcher = new Researcher();
                researcher.setResearcherId(rs.getInt("researcher_id"));
                researcher.setName(rs.getString("name"));
                researcher.setEmail(rs.getString("email"));
                researcher.setPhoneNumber(rs.getString("phone_number"));
                researcher.setSpecialization(rs.getString("specialization"));
                researchers.add(researcher);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return researchers;
    }
}
