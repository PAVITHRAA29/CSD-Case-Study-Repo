package dao;

import model.Sample;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
/**
 * Data Access Object for performing CRUD operations on Sample entities.
 */

public class SampleDAO {
	/**
     * Establishes a connection to the database.
     * @return Connection object
     * @throws SQLException if a database access error occurs
     */
    private Connection getConnection() throws SQLException {
        return DriverManager.getConnection("jdbc:mysql://localhost:3306/lab_management", "root", "password");
    }
    /**
     * Adds a new sample to the database.
     * @param sample The sample to be added.
     */
    public void addSample(Sample sample) {
        String sql = "INSERT INTO Sample (experiment_id, name, type, quantity) VALUES (?, ?, ?, ?)";
        try (Connection conn = getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, sample.getExperimentId());
            stmt.setString(2, sample.getName());
            stmt.setString(3, sample.getType());
            stmt.setInt(4, sample.getQuantity());
            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    /**
     * Retrieves a sample from the database by its ID.
     * @param sampleId The ID of the sample to retrieve.
     * @return The retrieved sample, or null if not found.
     */

    public Sample getSample(int sampleId) {
        Sample sample = null;
        String sql = "SELECT * FROM Sample WHERE sample_id = ?";
        try (Connection conn = getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, sampleId);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                sample = new Sample();
                sample.setSampleId(rs.getInt("sample_id"));
                sample.setExperimentId(rs.getInt("experiment_id"));
                sample.setName(rs.getString("name"));
                sample.setType(rs.getString("type"));
                sample.setQuantity(rs.getInt("quantity"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return sample;
    }
    /**
     * Updates an existing sample in the database.
     * @param sample The sample with updated information.
     */

    public void updateSample(Sample sample) {
        String sql = "UPDATE Sample SET experiment_id = ?, name = ?, type = ?, quantity = ? WHERE sample_id = ?";
        try (Connection conn = getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, sample.getExperimentId());
            stmt.setString(2, sample.getName());
            stmt.setString(3, sample.getType());
            stmt.setInt(4, sample.getQuantity());
            stmt.setInt(5, sample.getSampleId());
            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    /**
     * Deletes a sample from the database by its ID.
     * @param sampleId The ID of the sample to delete.
     */

    public void deleteSample(int sampleId) {
        String sql = "DELETE FROM Sample WHERE sample_id = ?";
        try (Connection conn = getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, sampleId);
            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    /**
     * Retrieves all samples from the database.
     * @return A list of all samples.
     */

    public List<Sample> getAllSamples() {
        List<Sample> samples = new ArrayList<>();
        String sql = "SELECT * FROM Sample";
        try (Connection conn = getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                Sample sample = new Sample();
                sample.setSampleId(rs.getInt("sample_id"));
                sample.setExperimentId(rs.getInt("experiment_id"));
                sample.setName(rs.getString("name"));
                sample.setType(rs.getString("type"));
                sample.setQuantity(rs.getInt("quantity"));
                samples.add(sample);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return samples;
    }
}
