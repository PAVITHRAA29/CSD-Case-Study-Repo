package dao;


/**
 * Data Access Object for performing CRUD operations on Experiment entities.
 */

import model.Experiment;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class ExperimentDAO {
	 /**
     * Establishes a connection to the database.
     * @return Connection object
     * @throws SQLException if a database access error occurs
     */
    private Connection getConnection() throws SQLException {
        return DriverManager.getConnection("jdbc:mysql://localhost:3306/lab_management", "root", "password");
    }

    /**
     * Adds a new experiment to the database.
     * @param experiment The experiment to be added.
     */

    public void addExperiment(Experiment experiment) {
        String sql = "INSERT INTO Experiment (name, description, start_date, end_date) VALUES (?, ?, ?, ?)";
        try (Connection conn = getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, experiment.getName());
            stmt.setString(2, experiment.getDescription());
            stmt.setString(3, experiment.getStartDate());
            stmt.setString(4, experiment.getEndDate());
            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    /**
     * Retrieves an experiment from the database by its ID.
     * @param experimentId The ID of the experiment to retrieve.
     * @return The retrieved experiment, or null if not found.
     */

    public Experiment getExperiment(int experimentId) {
        Experiment experiment = null;
        String sql = "SELECT * FROM Experiment WHERE experiment_id = ?";
        try (Connection conn = getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, experimentId);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                experiment = new Experiment();
                experiment.setExperimentId(rs.getInt("experiment_id"));
                experiment.setName(rs.getString("name"));
                experiment.setDescription(rs.getString("description"));
                experiment.setStartDate(rs.getString("start_date"));
                experiment.setEndDate(rs.getString("end_date"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return experiment;
    }
    /**
     * Updates an existing experiment in the database.
     * @param experiment The experiment with updated information.
     */

    public void updateExperiment(Experiment experiment) {
        String sql = "UPDATE Experiment SET name = ?, description = ?, start_date = ?, end_date = ? WHERE experiment_id = ?";
        try (Connection conn = getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, experiment.getName());
            stmt.setString(2, experiment.getDescription());
            stmt.setString(3, experiment.getStartDate());
            stmt.setString(4, experiment.getEndDate());
            stmt.setInt(5, experiment.getExperimentId());
            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    /**
     * Deletes an experiment from the database by its ID.
     * @param experimentId The ID of the experiment to delete.
     */

    public void deleteExperiment(int experimentId) {
        String sql = "DELETE FROM Experiment WHERE experiment_id = ?";
        try (Connection conn = getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, experimentId);
            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    /**
     * Retrieves all experiments from the database.
     * @return A list of all experiments.
     */

    public List<Experiment> getAllExperiments() {
        List<Experiment> experiments = new ArrayList<>();
        String sql = "SELECT * FROM Experiment";
        try (Connection conn = getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                Experiment experiment = new Experiment();
                experiment.setExperimentId(rs.getInt("experiment_id"));
                experiment.setName(rs.getString("name"));
                experiment.setDescription(rs.getString("description"));
                experiment.setStartDate(rs.getString("start_date"));
                experiment.setEndDate(rs.getString("end_date"));
                experiments.add(experiment);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return experiments;
    }
}
