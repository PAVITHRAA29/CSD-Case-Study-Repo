\# Life Sciences Research Lab Management System

\## Overview

This is a menu-based console application for managing experiments,
samples, and researchers in a life sciences research lab. The
application is developed using Core Java, MySQL, and JDBC.

\## Features

1\. \*\*Experiment Management:\*\*  - Add a new experiment  - View
experiment details  - Update experiment information  - Delete an
experiment

2\. \*\*Sample Management:\*\*  - Add a new sample  - View sample
details  - Update sample information  - Delete a sample

3\. \*\*Researcher Management:\*\*  - Add a new researcher  - View
researcher details  - Update researcher information  - Delete a
researcher

\## Database Schema

\- \*\*Experiment Table:\*\*  - \`experiment_id\` (Primary Key)  -
\`name\`  - \`description\`  - \`start_date\`  - \`end_date\`

\- \*\*Sample Table:\*\*  - \`sample_id\` (Primary Key)  -
\`experiment_id\` (Foreign Key references Experiment Table)  - \`name\`
 - \`type\`  - \`quantity\`

\- \*\*Researcher Table:\*\*  - \`researcher_id\` (Primary Key)  -
\`name\`  - \`email\`  - \`phone_number\`  - \`specialization\`

\## Setup

1\. \*\*Database Setup:\*\*  - Create the MySQL database and required
tables using the provided SQL script.

2\. \*\*Project Structure:\*\*  - Organize your project directory as
follows:

/project │ ├── /src │ ├── /model │ │ ├── Experiment.java │ │ ├──
Sample.java │ │ └── Researcher.java │ │ │ ├── /dao │ │ ├──
ExperimentDAO.java │ │ ├── SampleDAO.java │ │ └── ResearcherDAO.java │ │
│ ├── /service │ │ ├── ExperimentService.java │ │ ├── SampleService.java
│ │ └── ResearcherService.java │ │ │ └── /ui │ └── MainMenu.java │ ├──
/lib │ └── mysql-connector-java-x.x.xx.jar │ └── README.md

3\. \*\*Dependencies:\*\*  - Download the MySQL Connector/J library and
place it in the \`/lib\` directory.

4\. \*\*Compilation and Execution:\*\*  - Compile the project using your
favorite Java IDE or the command line: \`\`\`bash javac -cp
\".:lib/mysql-connector-java-x.x.xx.jar\" ui/MainMenu.java \`\`\`  - Run
the application: \`\`\`bash java -cp
\".:lib/mysql-connector-java-x.x.xx.jar\" ui.MainMenu \`\`\`

\## Usage

\- The application starts with the main menu, allowing users to choose
between managing experiments, samples, and researchers. - Navigate
through the menu to perform various CRUD operations.

\## Authors

\- \*\*\[Balabhadra Devi Anusha\]\*\*
