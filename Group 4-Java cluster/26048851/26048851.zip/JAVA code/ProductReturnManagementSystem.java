import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

public class ProductReturnManagementSystem {

    private static final String DB_URL = "jdbc:mysql://localhost:3306/ProductReturnDB";
    private static final String USER = "root";
    private static final String PASS = "password";

    private static Connection conn;

    public static void main(String[] args) {
        try {
            conn = DriverManager.getConnection(DB_URL, USER, PASS);
            menu();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private static void menu() {
        Scanner scanner = new Scanner(System.in);
        while (true) {
            System.out.println("1. Register a new return request");
            System.out.println("2. View return request details");
            System.out.println("3. Update return request status");
            System.out.println("4. Delete a return request");
            System.out.println("5. Process a return request");
            System.out.println("6. View processing details");
            System.out.println("7. Update processing status");
            System.out.println("8. Delete processing records");
            System.out.println("9. Update inventory after a return is processed");
            System.out.println("10. View current inventory status");
            System.out.println("11. Update inventory information");
            System.out.println("12. Delete inventory records");
            System.out.println("13. Exit");

            int choice = scanner.nextInt();
            scanner.nextLine(); // consume newline

            switch (choice) {
                case 1:
                    registerReturnRequest(scanner);
                    break;
                case 2:
                    viewReturnRequest(scanner);
                    break;
                case 3:
                    updateReturnRequestStatus(scanner);
                    break;
                case 4:
                    deleteReturnRequest(scanner);
                    break;
                case 5:
                    processReturnRequest(scanner);
                    break;
                case 6:
                    viewProcessingDetails(scanner);
                    break;
                case 7:
                    updateProcessingStatus(scanner);
                    break;
                case 8:
                    deleteProcessingRecords(scanner);
                    break;
                case 9:
                    updateInventoryAfterReturn(scanner);
                    break;
                case 10:
                    viewInventoryStatus(scanner);
                    break;
                case 11:
                    updateInventoryInformation(scanner);
                    break;
                case 12:
                    deleteInventoryRecords(scanner);
                    break;
                case 13:
                    System.out.println("Exiting...");
                    scanner.close();
                    System.exit(0);
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }

    // Method implementations for each menu option go here
    private static void registerReturnRequest(Scanner scanner) {
        try {
            System.out.print("Enter customer_id: ");
            int customerId = scanner.nextInt();
            System.out.print("Enter product_id: ");
            int productId = scanner.nextInt();
            scanner.nextLine(); // consume newline
            System.out.print("Enter reason for return: ");
            String reason = scanner.nextLine();
            System.out.print("Enter status: ");
            String status = scanner.nextLine();

            String sql = "INSERT INTO ReturnRequest (customer_id, product_id, request_date, reason, status) VALUES (?, ?, CURDATE(), ?, ?)";
            PreparedStatement pstmt = conn.prepareStatement(sql);
            pstmt.setInt(1, customerId);
            pstmt.setInt(2, productId);
            pstmt.setString(3, reason);
            pstmt.setString(4, status);
            pstmt.executeUpdate();

            System.out.println("Return request registered successfully.");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private static void viewReturnRequest(Scanner scanner) {
        try {
            System.out.print("Enter request_id: ");
            int requestId = scanner.nextInt();

            String sql = "SELECT * FROM ReturnRequest WHERE request_id = ?";
            PreparedStatement pstmt = conn.prepareStatement(sql);
            pstmt.setInt(1, requestId);
            ResultSet rs = pstmt.executeQuery();

            if (rs.next()) {
                System.out.println("Request ID: " + rs.getInt("request_id"));
                System.out.println("Customer ID: " + rs.getInt("customer_id"));
                System.out.println("Product ID: " + rs.getInt("product_id"));
                System.out.println("Request Date: " + rs.getDate("request_date"));
                System.out.println("Reason: " + rs.getString("reason"));
                System.out.println("Status: " + rs.getString("status"));
            } else {
                System.out.println("Return request not found.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private static void updateReturnRequestStatus(Scanner scanner) {
        try {
            System.out.print("Enter request_id: ");
            int requestId = scanner.nextInt();
            scanner.nextLine(); // consume newline
            System.out.print("Enter new status: ");
            String status = scanner.nextLine();

            String sql = "UPDATE ReturnRequest SET status = ? WHERE request_id = ?";
            PreparedStatement pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, status);
            pstmt.setInt(2, requestId);
            pstmt.executeUpdate();

            System.out.println("Return request status updated successfully.");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private static void deleteReturnRequest(Scanner scanner) {
        try {
            System.out.print("Enter request_id: ");
            int requestId = scanner.nextInt();

            String sql = "DELETE FROM ReturnRequest WHERE request_id = ?";
            PreparedStatement pstmt = conn.prepareStatement(sql);
            pstmt.setInt(1, requestId);
            pstmt.executeUpdate();

            System.out.println("Return request deleted successfully.");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private static void processReturnRequest(Scanner scanner) {
        try {
            System.out.print("Enter request_id: ");
            int requestId = scanner.nextInt();
            scanner.nextLine(); // consume newline
            System.out.print("Enter processing details: ");
            String details = scanner.nextLine();
            System.out.print("Enter status: ");
            String status = scanner.nextLine();

            String sql = "INSERT INTO Processing (request_id, processing_date, processing_details, status) VALUES (?, CURDATE(), ?, ?)";
            PreparedStatement pstmt = conn.prepareStatement(sql);
            pstmt.setInt(1, requestId);
            pstmt.setString(2, details);
            pstmt.setString(3, status);
            pstmt.executeUpdate();

            System.out.println("Return request processed successfully.");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private static void viewProcessingDetails(Scanner scanner) {
        try {
            System.out.print("Enter processing_id: ");
            int processingId = scanner.nextInt();

            String sql = "SELECT * FROM Processing WHERE processing_id = ?";
            PreparedStatement pstmt = conn.prepareStatement(sql);
            pstmt.setInt(1, processingId);
            ResultSet rs = pstmt.executeQuery();

            if (rs.next()) {
                System.out.println("Processing ID: " + rs.getInt("processing_id"));
                System.out.println("Request ID: " + rs.getInt("request_id"));
                System.out.println("Processing Date: " + rs.getDate("processing_date"));
                System.out.println("Processing Details: " + rs.getString("processing_details"));
                System.out.println("Status: " + rs.getString("status"));
            } else {
                System.out.println("Processing record not found.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private static void updateProcessingStatus(Scanner scanner) {
        try {
            System.out.print("Enter processing_id: ");
            int processingId = scanner.nextInt();
            scanner.nextLine(); // consume newline
            System.out.print("Enter new status: ");
            String status = scanner.nextLine();

            String sql = "UPDATE Processing SET status = ? WHERE processing_id = ?";
            PreparedStatement pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, status);
            pstmt.setInt(2, processingId);
            pstmt.executeUpdate();

            System.out.println("Processing status updated successfully.");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private static void deleteProcessingRecords(Scanner scanner) {
        try {
            System.out.print("Enter processing_id: ");
            int processingId = scanner.nextInt();

            String sql = "DELETE FROM Processing WHERE processing_id = ?";
            PreparedStatement pstmt = conn.prepareStatement(sql);
            pstmt.setInt(1, processingId);
            pstmt.executeUpdate();

            System.out.println("Processing record deleted successfully.");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private static void updateInventoryAfterReturn(Scanner scanner) {
        try {
            System.out.print("Enter product_id: ");
            int productId = scanner.nextInt();
            System.out.print("Enter quantity to add: ");
            int quantity = scanner.nextInt();

            String sql = "UPDATE Inventory SET stock_quantity = stock_quantity + ? WHERE product_id = ?";
            PreparedStatement pstmt = conn.prepareStatement(sql);
            pstmt.setInt(1, quantity);
            pstmt.setInt(2, productId);
            pstmt.executeUpdate();

            System.out.println("Inventory updated successfully.");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private static void viewInventoryStatus(Scanner scanner) {
        try {
            System.out.print("Enter product_id: ");
            int productId = scanner.nextInt();

            String sql = "SELECT * FROM Inventory WHERE product_id = ?";
            PreparedStatement pstmt = conn.prepareStatement(sql);
            pstmt.setInt(1, productId);
            ResultSet rs = pstmt.executeQuery();

            if (rs.next()) {
                System.out.println("Product ID: " + rs.getInt("product_id"));
                System.out.println("Stock Quantity: " + rs.getInt("stock_quantity"));
            } else {
                System.out.println("Inventory record not found.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private static void updateInventoryInformation(Scanner scanner) {
        try {
            System.out.print("Enter product_id: ");
            int productId = scanner.nextInt();
            System.out.print("Enter new stock quantity: ");
            int quantity = scanner.nextInt();

            String sql = "UPDATE Inventory SET stock_quantity = ? WHERE product_id = ?";
            PreparedStatement pstmt = conn.prepareStatement(sql);
            pstmt.setInt(1, quantity);
            pstmt.setInt(2, productId);
            pstmt.executeUpdate();

            System.out.println("Inventory information updated successfully.");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private static void deleteInventoryRecords(Scanner scanner) {
        try {
            System.out.print("Enter product_id: ");
            int productId = scanner.nextInt();

            String sql = "DELETE FROM Inventory WHERE product_id = ?";
            PreparedStatement pstmt = conn.prepareStatement(sql);
            pstmt.setInt(1, productId);
            pstmt.executeUpdate();

            System.out.println("Inventory record deleted successfully.");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
