# Product Return Management System

## Overview
This is a console-based application for managing product return requests, processing, and inventory updates for a consumer electronics company. The application is developed using Core Java, JDBC, and MySQL.

## Prerequisites
- Java Development Kit (JDK)
- MySQL Database Server
- MySQL JDBC Driver

## Setup Instructions

1. **Clone the Repository:**
    ```bash
    git clone https://github.com/HarshalTambe99/ProductReturnManagementSystem.git
    cd ProductReturnManagementSystem
    ```

2. **Create Database and Tables:**
    Run the SQL script provided in the repository to create the required database and tables.

3. **Update Database Credentials:**
    Update the database URL, username, and password in the `ProductReturnManagementSystem.java` file.

4. **Compile and Run the Application:**
    ```bash
    javac ProductReturnManagementSystem.java
    java ProductReturnManagementSystem
    ```

## Usage
- Follow the menu options to perform various operations like registering return requests, viewing details, updating statuses, processing returns, and managing inventory.
- Handle exceptions effectively and ensure the application code is clean, well-documented, and follows standard coding conventions.

Contributors
Harshal Tambe