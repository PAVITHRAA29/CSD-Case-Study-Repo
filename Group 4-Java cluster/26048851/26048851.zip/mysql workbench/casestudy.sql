CREATE DATABASE ProductReturnDB;

USE ProductReturnDB;

CREATE TABLE Customer (
    customer_id INT PRIMARY KEY AUTO_INCREMENT,
    customer_name VARCHAR(100)
);

CREATE TABLE Product (
    product_id INT PRIMARY KEY AUTO_INCREMENT,
    product_name VARCHAR(100)
);

CREATE TABLE ReturnRequest (
    request_id INT PRIMARY KEY AUTO_INCREMENT,
    customer_id INT,
    product_id INT,
    request_date DATE,
    reason VARCHAR(255),
    status VARCHAR(50),
    FOREIGN KEY (customer_id) REFERENCES Customer(customer_id),
    FOREIGN KEY (product_id) REFERENCES Product(product_id)
);

CREATE TABLE Processing (
    processing_id INT PRIMARY KEY AUTO_INCREMENT,
    request_id INT,
    processing_date DATE,
    processing_details VARCHAR(255),
    status VARCHAR(50),
    FOREIGN KEY (request_id) REFERENCES ReturnRequest(request_id)
);

CREATE TABLE Inventory (
    product_id INT PRIMARY KEY,
    stock_quantity INT,
    FOREIGN KEY (product_id) REFERENCES Product(product_id)
);
