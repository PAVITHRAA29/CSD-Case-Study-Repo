import java.util.ArrayList;
import java.util.HashMap;

public class OnlineAuctionSystem {
    private HashMap<Integer, Item> items = new HashMap<>();
    private HashMap<Integer, ArrayList<Bid>> bids = new HashMap<>();
    private int itemCounter = 1;
    private int bidCounter = 1;

    // Adds a new item to the auction system
    public void addItem(String name, String description, double startingPrice) {
        Item item = new Item(itemCounter++, name, description, startingPrice);
        items.put(item.getId(), item);
        System.out.println("Item added: " + item);
    }

    // Removes an item from the auction system
    public void removeItem(int itemId) {
        items.remove(itemId);
        bids.remove(itemId);
        System.out.println("Item removed with ID: " + itemId);
    }

    // Updates an existing item's details
    public void updateItem(int itemId, String name, String description, double startingPrice) {
        Item item = items.get(itemId);
        if (item != null) {
            item.setName(name);
            item.setDescription(description);
            item.setStartingPrice(startingPrice);
            System.out.println("Item updated: " + item);
        } else {
            System.out.println("Item not found with ID: " + itemId);
        }
    }

    // Starts the auction for an item
    public void startAuction(int itemId) {
        Item item = items.get(itemId);
        if (item != null) {
            item.setAuctionOpen(true);
            System.out.println("Auction started for item: " + item);
        } else {
            System.out.println("Item not found with ID: " + itemId);
        }
    }

    // Ends the auction for an item
    public void endAuction(int itemId) {
        Item item = items.get(itemId);
        if (item != null) {
            item.setAuctionOpen(false);
            System.out.println("Auction ended for item: " + item);
        } else {
            System.out.println("Item not found with ID: " + itemId);
        }
    }

    // Places a bid on an item
    public void placeBid(int itemId, int userId, double bidAmount) {
        Item item = items.get(itemId);
        if (item != null && item.isAuctionOpen()) {
            if (bidAmount > item.getCurrentHighestBid()) {
                Bid bid = new Bid(bidCounter++, itemId, userId, bidAmount);
                bids.computeIfAbsent(itemId, k -> new ArrayList<>()).add(bid);
                item.setCurrentHighestBid(bidAmount);
                System.out.println("Bid placed: " + bid);
            } else {
                System.out.println("Bid amount must be higher than the current highest bid.");
            }
        } else {
            System.out.println("Auction is not open for item with ID: " + itemId);
        }
    }

    // Views the auction status of all items
    public void viewAuctionStatus() {
        for (Item item : items.values()) {
            if (item.isAuctionOpen()) {
                System.out.println("Item: " + item);
                ArrayList<Bid> itemBids = bids.get(item.getId());
                if (itemBids != null) {
                    for (Bid bid : itemBids) {
                        System.out.println("\tBid: " + bid);
                    }
                } else {
                    System.out.println("\tNo bids yet.");
                }
            }
        }
    }
}
