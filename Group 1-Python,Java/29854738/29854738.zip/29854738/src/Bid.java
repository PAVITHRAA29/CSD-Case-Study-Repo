import java.time.LocalDateTime;

public class Bid {
    int id;
    int itemId;
    int userId;
    double bidAmount;
    LocalDateTime bidDateTime;

    public Bid(int id, int itemId, int userId, double bidAmount){
        this.id=id;
        this.itemId=itemId;
        this.userId=userId;
        this.bidAmount=bidAmount;
        this.bidDateTime=LocalDateTime.now();
    }
    public int getId(){
        return id;
    }
    public void setId(int id){
        this.id=id;
    }
    public int getItemId(){
        return itemId;
    }
    public void setItemId(int itemId){
        this.itemId=itemId;
    }
    public int getUserId(){
        return userId;
    }
    public void setUserId(int userId){
        this.userId=userId;
    }
    public double bidAmount(){
        return bidAmount;
    }
    public void setBidAmount(double bidAmount){
        this.bidAmount=bidAmount;
    }
    public LocalDateTime getDateTime(){
        return bidDateTime;
    }
    public void setBidDateTime(LocalDateTime bidDateTime){
        this.bidDateTime=LocalDateTime.now();
    }

    public String toString(){
        return "Bid:"+
        " id=" +id+
        " itemId=" +itemId+
        " userId=" +userId+
        " bidAmount=" +bidAmount+
        " bidDateTime=" +bidDateTime;
                
    }
}
