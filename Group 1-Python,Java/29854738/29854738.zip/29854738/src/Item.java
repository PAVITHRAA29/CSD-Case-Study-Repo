public class Item {
    private int id;
    private String name;
    private String description;
    private double startingPrice;
    private double currentHighestBid;
    private boolean isAuctionOpen;

    public Item(int id, String name, String description, double startingPrice) {
        this.id = id;
        this.name = name;
        this.description = description;
        this.startingPrice = startingPrice;
        this.currentHighestBid = startingPrice;
        this.isAuctionOpen = false;
    }

    // Getters and Setters
    public int getId() { 
        return id; 
    }
    public String getName() { 
        return name; 
    }
    public String getDescription() { 
        return description; 
    }
    public double getStartingPrice() {
         return startingPrice; 
        }
    public double getCurrentHighestBid() {
         return currentHighestBid; 
        }
    public boolean isAuctionOpen() { 
        return isAuctionOpen; 
    }
    public void setName(String name) {
         this.name = name; 
        }
    public void setDescription(String description) {
         this.description = description;
        }
    public void setStartingPrice(double startingPrice) {
         this.startingPrice = startingPrice; 
        }
    public void setCurrentHighestBid(double currentHighestBid) {
         this.currentHighestBid = currentHighestBid; 
        }
    public void setAuctionOpen(boolean isAuctionOpen) {
         this.isAuctionOpen = isAuctionOpen; 
        }

    public String toString() {
        return "Item{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", description='" + description + '\'' +
                ", startingPrice=" + startingPrice +
                ", currentHighestBid=" + currentHighestBid +
                ", isAuctionOpen=" + isAuctionOpen +
                '}';
    }
}
