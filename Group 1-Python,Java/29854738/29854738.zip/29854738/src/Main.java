import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        OnlineAuctionSystem auctionSystem = new OnlineAuctionSystem();
        Scanner scanner = new Scanner(System.in);
        boolean running = true;

        while (running) {
            System.out.println("1. Add Item");
            System.out.println("2. Remove Item");
            System.out.println("3. Update Item");
            System.out.println("4. Start Auction");
            System.out.println("5. End Auction");
            System.out.println("6. Place Bid");
            System.out.println("7. View Auction Status");
            System.out.println("8. Exit");
            System.out.print("Choose an option: ");
            int choice = scanner.nextInt();
            scanner.nextLine(); // Consume newline

            switch (choice) {
                case 1:
                    System.out.print("Enter item name: ");
                    String name = scanner.nextLine();
                    System.out.print("Enter item description: ");
                    String description = scanner.nextLine();
                    System.out.print("Enter starting price: ");
                    double startingPrice = scanner.nextDouble();
                    auctionSystem.addItem(name, description, startingPrice);
                    break;
                case 2:
                    System.out.print("Enter item ID to remove: ");
                    int removeId = scanner.nextInt();
                    auctionSystem.removeItem(removeId);
                    break;
                case 3:
                    System.out.print("Enter item ID to update: ");
                    int updateId = scanner.nextInt();
                    scanner.nextLine(); // Consume newline
                    System.out.print("Enter new name: ");
                    String newName = scanner.nextLine();
                    System.out.print("Enter new description: ");
                    String newDescription = scanner.nextLine();
                    System.out.print("Enter new starting price: ");
                    double newStartingPrice = scanner.nextDouble();
                    auctionSystem.updateItem(updateId, newName, newDescription, newStartingPrice);
                    break;
                case 4:
                    System.out.print("Enter item ID to start auction: ");
                    int startAuctionId = scanner.nextInt();
                    auctionSystem.startAuction(startAuctionId);
                    break;
                case 5:
                    System.out.print("Enter item ID to end auction: ");
                    int endAuctionId = scanner.nextInt();
                    auctionSystem.endAuction(endAuctionId);
                    break;
                case 6:
                    System.out.print("Enter item ID to place bid: ");
                    int itemId = scanner.nextInt();
                    System.out.print("Enter user ID: ");
                    int userId = scanner.nextInt();
                    System.out.print("Enter bid amount: ");
                    double bidAmount = scanner.nextDouble();
                    auctionSystem.placeBid(itemId, userId, bidAmount);
                    break;
                case 7:
                    auctionSystem.viewAuctionStatus();
                    break;
                case 8:
                    running = false;
                    System.out.println("Exiting...");
                    break;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }

        scanner.close();
    }
}
